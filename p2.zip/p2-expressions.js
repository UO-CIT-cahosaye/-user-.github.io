/*
    CIT 281 Project 2
    Name: Chace Fery
*/

// Returns a random number between min (inclusive) and max (exclusive)
// Rewrite
const getRandomInteger = function (minLength, maxLength) {
    return Math.floor(Math.random() * (maxLength - minLength) + minLength);
}

const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");

let result = "";

let lengthOfOutputString = getRandomInteger(5, 27);

//getRandomLetter() return a single lowercase letter 
// Rewrite
const getRandomLetter = function () {
    return alphabet[getRandomInteger(0, alphabet.length)];
}


//getRandomString(minLength, maxLength) return a random length string 
// Rewrite
const getRandomString = function (minLength, maxLength) {
    for (let i = 0; i < getRandomInteger(minLength, maxLength); i++) {
        result += getRandomLetter();
    }
    return result
}
// Rewrite
const getSortedString = function (string){
    return string.split('').sort().join('')
}
//Test
//console.log(getSortedString('xpacd'))
console.log(getSortedString(getRandomString(10, 20)));