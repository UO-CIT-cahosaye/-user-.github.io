/*
    CIT 281 Project 2
    Name: Chace Fery
*/

// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(minLength, maxLength) {
    return Math.floor(Math.random() * (maxLength - minLength) + minLength);
}
//alphabet 
const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
//result
let result = "";
//length of result
let lengthOfOutputString = getRandomInteger(5, 27);

//getRandomLetter() return a single lowercase letter 
function getRandomLetter() {
    return alphabet[getRandomInteger(0, alphabet.length)];
}

//getRandomString(minLength, maxLength) return a random length string 
function getRandomString(minLength, maxLength) {
    for (let i = 0; i < getRandomInteger(minLength, maxLength); i++) {
        result += getRandomLetter();
    }
    return result
}
//Sorted string function
function getSortedString(string){
    return string.split('').sort().join('')
}
//Console.log Test Function
//console.log(getSortedString('xpacd'))
console.log(getSortedString(getRandomString(10, 20)));
