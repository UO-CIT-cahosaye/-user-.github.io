/*
    CIT 281 Project 4
    Name: Chace Fery
*/

// Part 4 - load data from p4-data
const first = require("./p4-data.js");

//Part 5
//get question func - return array of string - element is question
function getQuestions() {
  return first.data.map(e => e.question);
}

//get answers func - return array of string - element is answer
function getAnswers() {
  return first.data.map(e => e.answer);
}

//get question answers func - return data array obj
function getQuestionsAnswers() {
  return [ ...first.data ];
}

//get question func - return: question - number - error
function getQuestion(number = "") {
//number to integer
  number = Number.parseInt(number);
//get the question
  const question = first.data[number - 1]?.question || '';
//error string
  const error = question === '' ? 'not found' : '';
// return req object
  return {
    question: question,
    number: number,
    error: error,
  };
}

//get answer func - return: answer - number - error
function getAnswer(number = "") {
//number to integer
   number = Number.parseInt(number);
//get the answer
const answer = first.data[number - 1]?.answer || '';
//error string
   const error = question === '' ? 'not found' : '';
   return {
    answer: answer,
    number: number,
    error: error,
  };
}



// get question answer func - return: question - answer - number - error
function getQuestionAnswer(number = "") {
//number to integer
   number = Number.parseInt(number);
//get the question
   const question = first.data[number - 1]?.question || '';
//get the answer
   const answer = first.data[number - 1]?.answer || '';
//error string
   const error = question === '' ? 'not found' : '';
   return {
    question: question,
    answer: answer,
    number: number,
    error: error,
  };
}


//console.log(getQuestions());
//console.log(getAnswers());
//console.log(getQuestionsAnswers());
//console.log(getQuestion());
//console.log(getQuestion('yes'));
//console.log(getQuestion('1'));


/*****************************
  Module function testing
******************************/
function testing(category, ...args) {
    console.log(`\n** Testing ${category} **`);
    console.log("-------------------------------");
    for (const o of args) {
      console.log(`-> ${category}${o.d}:`);
      console.log(o.f);
    }
  }
  // Set a constant to true to test the appropriate function
  const testGetQs = false;
  const testGetAs = false;
  const testGetQsAs = false;
  const testGetQ = false;
  const testGetA = false;
  const testGetQA = false;
 // const testAdd = false;      // Extra credit
 // const testUpdate = false;   // Extra credit
//  const testDelete = false;   // Extra credit
/*****************************
  Module function testing
******************************/



// getQuestions()
if (testGetQs) {
    testing("getQuestions", { d: "()", f: getQuestions() });
  }
  
  // getAnswers()
  if (testGetAs) {
    testing("getAnswers", { d: "()", f: getAnswers() });
  }
  
  // getQuestionsAnswers()
  if (testGetQsAs) {
    testing("getQuestionsAnswers", { d: "()", f: getQuestionsAnswers() });
  }
  
  // getQuestion()
  if (testGetQ) {
    testing(
      "getQuestion",
      { d: "()", f: getQuestion() },      // Extra credit: +1
      { d: "(0)", f: getQuestion(0) },    // Extra credit: +1
      { d: "(1)", f: getQuestion(1) },
      { d: "(4)", f: getQuestion(4) }     // Extra credit: +1
    );
  }
  
  // getAnswer()
  if (testGetA) {
    testing(
      "getAnswer",
//      { d: "()", f: getAnswer() },        // Extra credit: +1
  //    { d: "(0)", f: getAnswer(0) },      // Extra credit: +1
 //     { d: "(1)", f: getAnswer(1) },
      { d: "(4)", f: getAnswer(4) }       // Extra credit: +1
    );
  }
  
  // getQuestionAnswer()
  if (testGetQA) {
    testing(
      "getQuestionAnswer",
      { d: "()", f: getQuestionAnswer() },    // Extra credit: +1
      { d: "(0)", f: getQuestionAnswer(0) },  // Extra credit: +1
      { d: "(1)", f: getQuestionAnswer(1) },
 //     { d: "(4)", f: getQuestionAnswer(4) }   // Extra credit: +1
    );
  }