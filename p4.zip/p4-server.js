/*
    CIT 281 Project 3
    Name: Chace Fery
*/

// import Fastify
const http = require("http");
const fs = require("fs");
const fastify = require("fastify")();
const { data } = require("./p4-module.js");


//Add route with Get verb
fastify.get("/", (request, reply)=>{
    //readFile
    fs.readFile(`${__dirname}/index.html`, (err, data)=>{
        //No error  200 if error 500
        if (err){
            reply 
            .code(500)
            .send("Error")
        } else {
            reply
            .code(200)
            .send(data)
        }
        
    })
})

// GET Verbs

// question
fastify.get("/question", (request, reply)=>{
    return first.data.map(e => e.question);

})

// answer
fastify.get("/answer", (request, reply)=>{
    return first.data.map(e => e.answer);
})

// questionanswer
fastify.get("/questionanswer", (request, reply)=>{
    return [ ...first.data ];
})

//question - number
fastify.get("/questionTonumber", (request, reply)=>{
    number = Number.parseInt(number);
    const answer = first.data[number - 1]?.answer || '';
       const error = question === '' ? 'not found' : '';
       return {
        answer: answer,
        number: number,
        error: error,
      };
    })


//answer - number
fastify.get("/answerTonumber", (request, reply)=>{
    number = Number.parseInt(number);
    const answer = first.data[number - 1]?.answer || '';
    return {
     answer: answer,
     number: number,
   };
})

//question-answer - number
fastify.get("/questionanswerTonumber", (request, reply)=>{
    number = Number.parseInt(number);
       const question = first.data[number - 1]?.question || '';
       const answer = first.data[number - 1]?.answer || '';
       return {
        question: question,
        answer: answer,
        number: number,
      };
    })

//route
fastify.get("/route", (request, reply)=>{
    const error = question === '' ? 'not found' : '';
    return {
        error: error,
  };
});

//listenIP to host
const listenIP = "localhost";
const listenPort = 8082;
fastify.listen(listenPort, listenIP, (err, adress) => {
    if (err) {
        console.log(err);
        process.exit(1);
    }
    console.log(`listining on ${listenIP}:${listenPort}`);
});
