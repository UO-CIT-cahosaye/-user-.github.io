/*
    CIT 281 Project 6
    Name: Chace Fery
*/

//Part 4 - Create and test Shape base class

// Shape Class
class Shape {
  // Constuctor with param
  constructor(sides = []) {
    this.sides = sides;
  }
  //Perimeter class
  perimeter() {
    // redcue array
    return this.sides.length ? this.sides.reduce((a, b) => a + b) : 0;
  }
}
//test Shape
console.log(new Shape([5, 10]).perimeter()); // 15
console.log(new Shape([1, 2, 3, 4, 5]).perimeter()); // 15
console.log(new Shape().perimeter()); // 0


// Part 5 - Implement and test Rectangle class

// Extend Rectangle
class Rectangle extends Shape {
  // Constuctor with param
  constructor(length = 0, width = 0) {
    //super
    super([length, width, length, width]);
    //length
    this.length = length;
    //width
    this.width = width;
  }
  // area
  area() {
    return this.length * this.width;
  }
}
//test Rectangle
console.log(new Rectangle(4, 4).perimeter()); // 16
console.log(new Rectangle(4, 4).area()); // 16
console.log(new Rectangle(5, 5).perimeter()); // 20
console.log(new Rectangle(5, 5).area()); // 25
console.log(new Rectangle().perimeter()); // 0
console.log(new Rectangle().area()); // 0


// Part 5 - Implement and test Triangle class

//Extend Triangle
class Triangle extends Shape {
  // Constuctor with param
  constructor(sideA = 0, sideB = 0, sideC = 0) {
    super([sideA, sideB, sideC]);
    //Side A
    this.sideA = sideA;
    //Side B
    this.sideB = sideB;
    //Side C
    this.sideC = sideC;
  }
  // Triangle Area
  area() {
    //Formula
    let variable = (this.sideA + this.sideB + this.sideC) / 2;
    return Math.sqrt(
      variable *
        ((variable - this.sideA) *
          (variable - this.sideB) *
          (variable - this.sideC))
    );
  }
}
//Test Triangle
console.log(new Triangle(3, 4, 5).perimeter()); // 12
console.log(new Triangle(3, 4, 5).area()); // 6
console.log(new Triangle().perimeter()); // 0
console.log(new Triangle().area()); // 0


// Part 6 - Create a generic block of code for processing an array of sides arrays

// dataset
const data = [[3, 4], [5, 5], [3, 4, 5], [10], []];
// store array data
for (const element of data) {
  let object = null;
  // length of element
  len = element.length;
  switch (
    len
  ) {
    // length with other value

    // Rectangle result
    case Rectangle: {
      object = new Rectangle(element[0], element[1]);
      // display result - rectangle
      console.log(
        `${
          object.length == object.width ? "Square" : "Rectangle"
        } with sides ${element.toString()} has perimeter of ${object.perimeter()} and area of ${object.area()}`
      );
      break;
    }

    // Triangle result
    case Triangle: {
      object = new Triangle(element[0], element[1], element[2]);
      // display result - triangle
      console.log(
        `Triangle with sides ${element.toString()} has perimeter of ${object.perimeter()} and area of ${object.area()}`
      );
      break;
    }

    // Default option
    default:
      console.log(`Shape with ${len} sides is unsupported`);
  }
}
