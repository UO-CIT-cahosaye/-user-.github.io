/*
    CIT 281 Project 1
    Name: Chace Fery
*/

// const - set value of array - days of week
const currentday = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
// day of week as number 
const value = new Date();
// define day - call back to currentday
let day = currentday[value.getDay()];
// return the day
console.log(day);