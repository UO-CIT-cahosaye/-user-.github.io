/*
    CIT 281 Project 1
    Name: Chace Fery 
*/

// Define characters
let letter = 'abcdefghijklmnopqrstuvwxyz'
// Split - value for each letter
let singleLetter = letter.split("");
// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}
// apply letter to value - random output 
const finalLetter = singleLetter.slice(getRandomIntiger(5, 25));
// return random letters
console.log(finalLetter);
