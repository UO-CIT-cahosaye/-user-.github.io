/*
    CIT 281 Project 3
    Name: Chace Fery
*/

//Part 7
// import Fastify
const http = require("http");
const fs = require("fs");
const fastify = require("fastify")();
//coinCount func
const { coinCount } = require("./p3-module.js");

//Part 8
//Add route with Get verb
fastify.get("/", (request, reply)=>{
    //readFile
    fs.readFile(`${__dirname}/index.html`, (err, data)=>{
        //No error  200 if error 500
        if (err){
            reply 
            .code(500)
            .header("Content-Type", "text/html")
            .send("Error")
        } else {
            reply
            .code(200)
            .header("Content-Type", "text/html")
            .send(data)
        }
        
    })
})

//Part 9 
//Coin route with GET 
fastify.get("/coin", (request, reply)=>{
    let {denom = 0, count = 0}=request.query;
    count=parseInt(count);
    denom=parseInt(denom);
let coinValue = coinCount({denom, count})
// return calc / status code / actual result
            reply
            .code(200)
            .header("Content-Type", "text/html; charset=utf-8")
            .send(`<h2>Value of ${count} of ${denom} is ${coinValue}</h2><br /><a href="/">Home</a>`)
        

}) 

//Part 10 
fastify.get("/coins", (request, reply)=>{
    let {option}=request.query;
    option = parseInt(option);
    let coinValue = [];
    const coins = [{denom: 25, count: 2},{denom: 1, count: 7}];
//Switch statment -> option values
    switch(option) {
        case 1: 
        coinValue = coinCount({ denom: 5, count: 3 }, { denom: 10, count: 2 })
        break;
        case 2: 
        coinValue = coinCount(...coins)
        break;
        default: 
        coinValue = 0
        break;
    }
        reply
        .code(200)
        .header("Content-Type", "text/html; charset=utf-8")
        .send(`<h2>Option ${option} value is ${coinValue}</h2><br /><a href="/">Home</a>`
        )

    })
//listenIP to host
const listenIP = "localhost";
const listenPort = 8082;
fastify.listen(listenPort, listenIP, (err, adress) => {
    if (err) {
        console.log(err);
        process.exit(1);
    }
    console.log(`listining on ${listenIP}:${listenPort}`);
});
